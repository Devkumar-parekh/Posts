import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { NavLink } from "react-router-dom";
// import setpostData from "../Redux/thunk";
import { setCommentData, setpostData, setuserData } from "../Redux/services";
function Posts() {
  const [pageNum, setpageNum] = useState(1);
  const [postpg, setpostpg] = useState(5);
  const [searchq, setsearchq] = useState("");
  const dispatch = useDispatch();
  const postData = useSelector((state) => state.postReducer);
  //   const userData = useSelector((state) => state.postReducer);
  useEffect(() => {
    // if (Object.keys(postData).length == 0) {
    dispatch(setpostData(searchq, pageNum, postpg));
    dispatch(setuserData());
    dispatch(setCommentData());
    // }
    console.log(postData);
  }, [searchq, pageNum, postpg]);

  const getUserName = (uid) => {
    return postData.users.find((user) => {
      return user.id == uid;
    });
  };
  const display = () => {
    if (postData.posts && postData.users) {
      // console.log(postpg == "");
      return postData.posts
        .slice(pageNum === 1 ? 0 : postpg * (pageNum - 1), postpg * pageNum)
        .map((val) => {
          // if (val.title.includes(searchq) || val.body.includes(searchq)) {
          return (
            <div className="col-md-4" key={val.id}>
              <div className=" border m-3 p-3 rounded">
                <h3 className="my-2">{val.title}</h3>
                <span className="my-2">
                  <i class="bi bi-person-circle me-2"></i>
                  {getUserName(val.userId).name}
                </span>
                <div className="my-2">{val.body}</div>
                <NavLink
                  to={`postdetails/${val.id}`}
                  className="text-decoration-none btn btn-outline-dark "
                >
                  View More <i class="bi bi-info-circle"></i>
                </NavLink>
              </div>
            </div>
          );
          // }
        });
    }
  };
  return (
    <>
      <h2 className="Posts m-3">Posts Page</h2>
      <div className="m-3 seacrh-box">
        <span className="input-group">
          <input
            value={searchq}
            placeholder="Search..."
            onChange={(e) => {
              setsearchq(e.target.value);
            }}
            className="border rounded-start"
          />
          <i class="bi bi-search input-group-text"></i>
        </span>
      </div>
      <div className="m-3">
        <button
          className=" btn btn-outline-secondary"
          onClick={() => {
            setpageNum(pageNum > 1 ? pageNum - 1 : pageNum);
          }}
        >
          <i class="bi bi-chevron-double-left"></i>Prev
        </button>
        <span className="mx-3">{pageNum}</span>
        <button
          className=" btn btn-outline-secondary"
          onClick={() => {
            setpageNum(pageNum + 1);
          }}
        >
          Next<i class="bi bi-chevron-double-right"></i>
        </button>
        <span className="float-end">
          Post Per Page:
          <input
            value={postpg}
            onChange={(e) => {
              setpostpg(e.target.value);
            }}
          />
        </span>
      </div>
      <div className="row g-3">{display()}</div>
    </>
  );
}

export default Posts;
