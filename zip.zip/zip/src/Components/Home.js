import { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
// import setpostData from "../Redux/thunk";
import { setpostData } from "../Redux/Actionpost";
import Posts from "./Posts";
function Home() {
  const dispatch = useDispatch();

  const postData = useSelector((state) => state.postReducer);

  // useEffect(() => {
  //   console.log(postData);
  //   dispatch(setpostData());
  // }, []);

  return (
    <>
      <div className="container my-5">
        <Posts />
      </div>
    </>
  );
}

export default Home;
