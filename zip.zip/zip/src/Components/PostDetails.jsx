import { Outlet } from "react-router-dom";

function PostDetails() {
  return (
    <div className="PostDetails">
      {/* PostDetails Page  */}
      <Outlet />
    </div>
  );
}

export default PostDetails;
