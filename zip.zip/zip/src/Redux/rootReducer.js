import { combineReducers } from "redux";
import { postReducer } from "./Reducerpost";

export const rootReducer = combineReducers({
  postReducer,
});
