import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Layout from "./Components/Layout";
import Home from "./Components/Home";
import { Provider } from "react-redux";
import { store } from "./Redux/Store";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import PostDetails from "./Components/PostDetails";
import PostDetail from "./Components/PostDetail";
import "../node_modules/bootstrap-icons/font/bootstrap-icons.css";
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  // <React.StrictMode>
  <Provider store={store}>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="postdetails" element={<PostDetails />}>
            <Route path=":postId" element={<PostDetail />} />
          </Route>
        </Route>
      </Routes>
    </BrowserRouter>
  </Provider>
  // </React.StrictMode>
);
